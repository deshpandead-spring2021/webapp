
pwd
cd /home/ubuntu
pwd
sudo chmod -R 777 webapp/
cd
cd /home/ubuntu/webapp/
pwd
sudo npm install pm2 -g
sudo apt update -y 
sudo apt clean 
sudo apt install -y curl 
curl -sL https://deb.nodesource.com/setup_12.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo apt install -y gcc g++ make
npm i -f