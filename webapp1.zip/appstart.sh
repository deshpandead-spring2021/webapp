cd
pwd
cd /home/ubuntu/webapp/nodejs-webapp
pwd
# printenv
# pm2 start server.js
pm2 start node server.js -f