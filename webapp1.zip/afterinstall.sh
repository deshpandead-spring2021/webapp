sudo pm2 kill
pwd
cd /home/ubuntu
pwd
sudo chmod -R 777 webapp/
cd
cd /home/ubuntu/webapp/nodejs-webapp
pwd
npm install